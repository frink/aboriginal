#ifndef WCHAR_MIN
#define WCHAR_MIN 0U
#define WCHAR_MAX 0xffffffffU
#endif
