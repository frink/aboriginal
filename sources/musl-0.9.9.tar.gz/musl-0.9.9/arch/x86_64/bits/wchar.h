#ifndef WCHAR_MIN
#define WCHAR_MIN (-1-0x7fffffff)
#define WCHAR_MAX (0x7fffffff)
#endif
