#include <complex.h>

long double (creall)(long double complex z)
{
	return creall(z);
}
