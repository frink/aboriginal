#include "libm.h"

float (cimagf)(float complex z)
{
	return cimagf(z);
}
