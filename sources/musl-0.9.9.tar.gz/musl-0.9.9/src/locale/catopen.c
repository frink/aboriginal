#include <nl_types.h>

nl_catd catopen (const char *name, int oflag)
{
	return (nl_catd)-1;
}
