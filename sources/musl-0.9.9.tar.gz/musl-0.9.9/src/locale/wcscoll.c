#include <wchar.h>

/* FIXME: stub */
int wcscoll(const wchar_t *l, const wchar_t *r)
{
	return wcscmp(l, r);
}
