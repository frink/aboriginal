#include <spawn.h>

int posix_spawnattr_destroy(posix_spawnattr_t *attr)
{
	return 0;
}
